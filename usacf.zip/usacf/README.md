# USACF Agent Suite - Universal Search & Analysis Cognitive Framework

> **12 specialized agents for comprehensive domain analysis** | Works across software, business, research, product domains
> **Token-optimized**: Concise summaries for AI agent consumption

## 🎯 Quick Reference Matrix

| Agent | Trigger | Input | Output | Key Use |
|-------|---------|-------|--------|---------|
| **meta-learning-orchestrator** | FIRST - before analysis | Subject description | Principles, questions, research plan | Establish foundation |
| **step-back-analyzer** | Phase 0 - principles | Any domain | 5-7 core principles + anti-patterns | Define excellence criteria |
| **ambiguity-clarifier** | Phase 0 - unclear terms | Requirements/specs | Resolved ambiguities + assumptions | Prevent misanalysis |
| **self-ask-decomposer** | Phase 0 - planning | Subject scope | 15-20 essential questions | Guide investigation |
| **structural-mapper** | Phase 1 - discovery | Codebase/system | Components + hierarchy + interfaces | Map architecture |
| **flow-analyst** | Phase 1 - discovery | System/process | End-to-end flows + bottlenecks | Trace pathways |
| **gap-hunter** | Phase 2 - analysis | Discovery findings | 7-dimension gap analysis | Find improvements |
| **risk-analyst** | Phase 2 - analysis | Gaps + flows | FMEA table with RPN scores | Quantify risks |
| **opportunity-generator** | Phase 3 - synthesis | Gaps + risks | 4-horizon opportunity portfolio | Transform to value |
| **adversarial-reviewer** | Phase 3 - validation | All findings | Critical review + weaknesses | Challenge assumptions |
| **confidence-quantifier** | Phase 3 - scoring | All findings | Truth scores + confidence intervals | Statistical rigor |
| **synthesis-specialist** | FINAL - reporting | All agent outputs | Executive summary + roadmap | Actionable report |

---

## 📋 Agent Descriptions

### 1. Meta-Learning Orchestrator
**Role**: Universal search coordinator (Agent #1/12)
**Core**: Step-back prompting, ReWOO planning, context tiering
**Triggers**: Use FIRST to establish analysis foundation
**Outputs**:
- 7+ core principles defining excellence
- 20+ essential questions guiding analysis
- Comprehensive research plan with dependencies
- Ambiguity resolutions, anti-patterns
**XP**: 320 XP for 7+ principles, 300 XP for 20+ questions

### 2. Step-Back Analyzer
**Role**: Universal principle extraction (Phase 0)
**Core**: First-principles thinking, evaluation frameworks
**Triggers**: Before diving into details
**Outputs**:
- 5-7 foundational principles (measurable, actionable)
- Success/failure criteria
- Anti-pattern catalog (10+)
- Cross-domain patterns
**XP**: 320 XP for 7+ principles, 260 XP for 10+ anti-patterns

### 3. Ambiguity Clarifier
**Role**: Terminology & requirement resolver (Phase 0)
**Core**: Multi-interpretation analysis, assumption documentation
**Triggers**: Vague qualifiers ("scalable", "fast"), quantitative terms without bounds
**Outputs**:
- 5-10+ ambiguous terms identified
- 2-3 interpretations per term (conservative/moderate/aggressive)
- Clarification questions with impact analysis
- Provisional assumptions with risk assessment
**XP**: 260 XP for 10+ ambiguities, 240 XP for all clarifications

### 4. Self-Ask Decomposer
**Role**: Essential question generator (Phase 0)
**Core**: 4-dimension decomposition (structural/functional/contextual/meta)
**Triggers**: Before deep analysis to identify knowledge gaps
**Outputs**:
- 15-20 critical questions across 4 dimensions
- Confidence scores (0-100%) per question
- Research flags (red/yellow/green)
- Priority ranking
**XP**: 300 XP for 20+ questions, 180 XP for confidence scoring

### 5. Structural Mapper
**Role**: Universal architecture analyzer (Phase 1 - Discovery)
**Core**: Component/hierarchy/interface/relationship mapping
**Triggers**: After principles established, first discovery agent
**Outputs**:
- Component inventory (20+)
- Hierarchy depth 5+ levels
- Interface catalog (15+)
- Relationship graph (25+)
- Completeness score (90%+)
**XP**: 340 XP for 20+ components, 320 XP for depth 5+

### 6. Flow Analyst
**Role**: Universal pathway tracer (Phase 1 - Discovery)
**Core**: End-to-end flow mapping, bottleneck detection
**Triggers**: After structural mapping completes
**Outputs**:
- 10+ traced end-to-end flows
- Bottleneck identification (5+)
- Critical path analysis
- Cycle/loop detection
- Throughput optimization paths
**XP**: 330 XP for 10+ flows, 310 XP for 5+ bottlenecks

### 7. Gap Hunter
**Role**: Multi-dimensional gap analyzer (Phase 2 - Analysis)
**Core**: 7-dimension gap detection (quality/performance/structural/resource/capability/security/UX)
**Triggers**: After discovery phase, before risk analysis
**Outputs**:
- 5+ gaps per dimension (35+ total)
- Severity + impact + effort scores
- Evidence-backed (3+ sources per gap)
- Priority matrix (P0/P1/P2/P3)
**XP**: 350 XP per dimension with 5+ gaps, 320 XP for quantified analysis

### 8. Risk Analyst
**Role**: FMEA specialist (Phase 2 - Analysis)
**Core**: Failure mode identification, RPN scoring (Severity × Occurrence × Detection)
**Triggers**: After gap analysis to quantify risks
**Outputs**:
- FMEA table with 15+ failure modes
- RPN scores (S/O/D ratings 1-10)
- Mitigation strategies (prevention/detection/severity reduction)
- Target RPN calculations
**XP**: 360 XP for 15+ failure modes, 340 XP for complete RPN analysis

### 9. Opportunity Generator
**Role**: Gap-to-value transformer (Phase 3 - Synthesis)
**Core**: 4-horizon portfolio (quick wins/strategic/transformational/disruptive)
**Triggers**: After gap + risk analysis to create action plan
**Outputs**:
- 10-15 quick wins (impact ≥7, effort ≤3)
- 8-12 strategic (3-12 months)
- 5-8 transformational (12-24 months)
- 3-5 disruptive (24+ months)
- Multi-dimensional scoring (impact/effort/risk/strategic fit)
**XP**: 400 XP for complete portfolio, 220 XP for stakeholder views

### 10. Adversarial Reviewer
**Role**: Devil's advocate red team (Phase 3 - Validation)
**Core**: Challenge assumptions, find weaknesses, prevent false positives
**Triggers**: BEFORE synthesis to ensure robust conclusions
**Outputs**:
- 10+ critical weaknesses identified
- 15+ challenged assumptions
- Alternative explanations
- Bias detection
- Evidence quality assessment (0-100)
**XP**: 400 XP for 10+ weaknesses, 380 XP for 15+ assumptions

### 11. Confidence Quantifier
**Role**: Statistical rigor specialist (Phase 3 - Final Quality Gate)
**Core**: Confidence intervals, truth scores, Bayesian updating
**Triggers**: AFTER adversarial review, BEFORE synthesis
**Outputs**:
- Confidence scores (0-100%) per finding
- 95% confidence intervals
- Evidence quality ratings (High/Medium/Low)
- Multi-approach validation (3+ methods for critical findings)
- Overall truth score (0-100)
**XP**: 360 XP for complete confidence scoring, 340 XP for multi-approach validation

### 12. Synthesis Specialist
**Role**: FINAL agent - comprehensive report generator (Phase 3 - Reporting)
**Core**: Cross-phase integration, executive summaries, implementation roadmaps
**Triggers**: LAST agent - synthesize all 11 prior outputs
**Outputs**:
- Executive summary (1-2 pages, top 3-5 findings)
- Technical report (8 sections)
- Priority matrix (P0/P1/P2/P3)
- Implementation roadmap (4 phases)
- Stakeholder views (users/technical/management)
- Confidence dashboard (truth score ≥85%)
**XP**: 420 XP for complete synthesis, 500 XP BONUS for perfect report (≥95% truth score)

---

## 🚀 Usage Workflow

### Recommended Execution Order

```bash
# PHASE 0: FOUNDATION (Parallel)
1. meta-learning-orchestrator  # Establish principles, plan
2. step-back-analyzer          # Core principles
3. ambiguity-clarifier         # Resolve unclear terms
4. self-ask-decomposer         # Generate questions

# PHASE 1: DISCOVERY (Sequential/Parallel)
5. structural-mapper           # Map components
6. flow-analyst                # Trace pathways

# PHASE 2: ANALYSIS (Sequential)
7. gap-hunter                  # 7-dimension gaps
8. risk-analyst                # FMEA + RPN scoring

# PHASE 3: SYNTHESIS (Sequential)
9. opportunity-generator       # Transform gaps to value
10. adversarial-reviewer       # Challenge findings
11. confidence-quantifier      # Statistical scoring
12. synthesis-specialist       # Final report
```

### Memory Coordination

All agents use `npx claude-flow memory` for coordination:

```bash
# Agents store findings at:
search/meta/principles          # Step-back principles
search/meta/self-ask-questions  # Essential questions
search/discovery/structural     # Component maps
search/discovery/flows          # Flow diagrams
search/gaps/multi-dimensional   # Gap analysis
search/risks/fmea               # Risk tables
search/opportunities/portfolio  # Opportunity matrix
search/synthesis/final-report   # Complete synthesis
```

---

## 🎮 Gamification Summary

**Total Possible XP per Analysis**: 4,000+ XP across all agents
**Level Progression**: Level 1 (0-500 XP) → Level 5 (2000+ XP) per agent
**Combo Multipliers**: Cross-agent coordination bonuses, speed bonuses, perfection bonuses

### Key XP Triggers
- **CRITICAL** (300-420 XP): Complete core responsibilities, high-volume outputs
- **HIGH** (150-220 XP): Advanced analysis, multi-method validation
- **MEDIUM** (75-120 XP): Quality scoring, evidence collection
- **BONUS** (100-500 XP): Perfect scores, novel insights, speed achievements

---

## 💡 Domain Adaptations

### Software Domain
- Structural: Classes, modules, APIs, databases
- Gaps: Code quality, test coverage, performance, security
- Risks: Crashes, security vulnerabilities, scalability issues

### Business Domain
- Structural: Departments, processes, workflows
- Gaps: Process inefficiencies, resource constraints, market position
- Risks: Compliance violations, market risks, operational failures

### Research Domain
- Structural: Hypotheses, variables, methodologies
- Gaps: Methodology flaws, reproducibility issues, ethical gaps
- Risks: Statistical errors, bias, ethical violations

### Product Domain
- Structural: Features, user journeys, integrations
- Gaps: UX friction, feature completeness, accessibility
- Risks: User errors, safety issues, market fit failures

---

## ⚡ Token Optimization Tips

1. **Use selectively**: Don't run all 12 agents for simple analyses
2. **Parallel where possible**: Phase 0 agents can run concurrently
3. **Skip redundant**: If no ambiguities, skip ambiguity-clarifier
4. **Focus on critical**: Prioritize high-XP agents for complex analyses
5. **Memory-first**: Check memory before spawning - avoid duplicate work

---

**Generated for**: AI agent consumption | Optimized for Claude Code task spawning
**Last Updated**: 2025-01-18
